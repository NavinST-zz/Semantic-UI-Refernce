package test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by NavinST on 18-03-2017.
 */
public class ConvertMain {

    private static final Logger logger = Logger.getLogger(ConvertMain.class.getName());

    public static void main(String args[]) throws Exception
    {
        logger.info("Starting the Conversion");
        String poFilePath = "src/test/test1.cp";
        String copyBookPath = "src/test/hed1.cbl";

        List<String> inputFiles = Arrays.asList(poFilePath);

        List<InputFileLine> convertedFiles = new ArrayList<>();
        inputFiles.forEach((file) -> {
            Comp3Decompressor zip = new Comp3Decompressor(file, copyBookPath);
            convertedFiles.addAll(zip.decompressFile());
        });
        generateOutputFile(convertedFiles);
    }

    private static void generateOutputFile(List<InputFileLine> convertedFiles) {
        DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'_'HHmmss");
        String formattedDate = dateFormat.format(Calendar.getInstance().getTime());
        try {
            File outputFile = new File("output_" + formattedDate + ".txt");
            if(!outputFile.exists()) {
                outputFile.createNewFile();
            }
            FileWriter fw = new FileWriter(outputFile.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(getResultContents(convertedFiles));
            bw.close();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    private static String getResultContents(List<InputFileLine> convertedFiles) {
        StringBuilder sb = new StringBuilder();
        for(InputFileLine ln : convertedFiles) {
            sb.append(ln.getPoId());
            sb.append(ln.getPoNumSourceCode());
            sb.append(ln.getLgclDelFlag());
            sb.append(ln.getPoActFlag());
            sb.append(ln.getVendId());
            sb.append(ln.getVendShipPntId());
            sb.append(ln.getFobPoint());
            sb.append(ln.getFrtAllow());
            sb.append(ln.getRtgCode());
            sb.append(ln.getCreateDate());
            sb.append(ln.getConfOrdFlag());
            sb.append(ln.getPoAutoGenCode());
            sb.append(ln.getPoNumTypeCode());
            sb.append(ln.getOoPoCanFlag());
            sb.append(ln.getImpCanFlag());
            sb.append(ln.getPoCreateCode());
            sb.append(ln.getApproveDate());
            sb.append(ln.getAppriveStatCode());
            sb.append(ln.getBoAuthFlg());
            sb.append(ln.getTermsOverrideCode());
            sb.append(ln.getDiscPd());
            sb.append(ln.getDatingTermsCode());
            sb.append(ln.getDatingTermdQty());
            sb.append(ln.getAddlTermsTypeCode());
            sb.append(ln.getAddlDiscPd());
            sb.append(ln.getAddlDatingTermsQty());
            sb.append(ln.getChangeDate());
            sb.append("\n");
        }
        return sb.toString();
    }
}
