package test;

/**
 * Created by NavinST on 18-03-2017.
 */
public class InputFileLine {

    private Integer poId;
    private String poNumSourceCode;
    private String lgclDelFlag;
    private String poActFlag;
    private Integer vendId;
    private Integer vendShipPntId;
    private String fobPoint;
    private String frtAllow;
    private String rtgCode;
    private String createDate;
    private String confOrdFlag;
    private String poAutoGenCode;
    private String poNumTypeCode;
    private String ooPoCanFlag;
    private String impCanFlag;
    private String poCreateCode;
    private String approveDate;
    private Integer appriveStatCode;
    private String boAuthFlg;
    private String termsOverrideCode;
    private Float discPd;
    private String datingTermsCode;
    private Integer datingTermdQty;
    private String addlTermsTypeCode;
    private Float addlDiscPd;
    private Integer addlDatingTermsQty;
    private String changeDate;
    private String changeUser;
    private String poPrismStatCode;
    private String shipDateTypeCode;
    private String earlyShipBeginDate;
    private String lateShipEndDate;
    private String lateShipEtaDate;
    private String poScndStatCode;
    private String alocDueDate;
    private String pymtTypeCode;
    private String ordPrpsCode;
    private String shipTermsCode;
    private String distbModeCode;
    private Integer spclTermMoId;
    private Integer scplTermYrId;
    private Integer otbMonId;
    private Integer otbMoWkId;
    private Integer OtbYrId;
    private String createUserId;
    private String approveUserId;
    private String cancelDate;
    private String cancelUserId;
    private String reinsDate;
    private String reinsUserId;
    private String impOrdFlag;
    private String boAuthOvrdFlag;
    private String frtAllowOvrdFlag;
    private String fobPntOvrdFlag;
    private String impStrgFlag;
    private Integer ordMinStoreQty;
    private Integer ordMinDcQty;
    private String ordMinMeasCode;
    private String vendMinStatCode;
    private String ipiFlag;
    private String ordConsFlag;
    private String vendPromoId;
    private String alocAutoAppFlag;
    private String alocReqFlag;
    private String BulLockFlag;
    private String autoReplPurgeFlag;
    private String recalcReqFlag;
    private String vendToGuesTFlag;
    private String ownBrandFlag;
    private String reqApproveTS;
    private String poUpdateLockFlag;
    private Integer srcTrakCode;
    private String autoCanExclFlag;

    public String getBoAuthFlg() {
        return boAuthFlg;
    }

    public void setBoAuthFlg(String boAuthFlg) {
        this.boAuthFlg = boAuthFlg;
    }

    public String getTermsOverrideCode() {
        return termsOverrideCode;
    }

    public void setTermsOverrideCode(String termsOverrideCode) {
        this.termsOverrideCode = termsOverrideCode;
    }

    public Float getDiscPd() {
        return discPd;
    }

    public void setDiscPd(Float discPd) {
        this.discPd = discPd;
    }

    public String getDatingTermsCode() {
        return datingTermsCode;
    }

    public void setDatingTermsCode(String datingTermsCode) {
        this.datingTermsCode = datingTermsCode;
    }

    public Integer getDatingTermdQty() {
        return datingTermdQty;
    }

    public void setDatingTermdQty(Integer datingTermdQty) {
        this.datingTermdQty = datingTermdQty;
    }

    public String getAddlTermsTypeCode() {
        return addlTermsTypeCode;
    }

    public void setAddlTermsTypeCode(String addlTermsTypeCode) {
        this.addlTermsTypeCode = addlTermsTypeCode;
    }

    public Float getAddlDiscPd() {
        return addlDiscPd;
    }

    public void setAddlDiscPd(Float addlDiscPd) {
        this.addlDiscPd = addlDiscPd;
    }

    public Integer getAddlDatingTermsQty() {
        return addlDatingTermsQty;
    }

    public void setAddlDatingTermsQty(Integer addlDatingTermsQty) {
        this.addlDatingTermsQty = addlDatingTermsQty;
    }

    public String getChangeDate() {
        return changeDate;
    }

    public void setChangeDate(String changeDate) {
        this.changeDate = changeDate;
    }

    public String getChangeUser() {
        return changeUser;
    }

    public void setChangeUser(String changeUser) {
        this.changeUser = changeUser;
    }

    public String getPoPrismStatCode() {
        return poPrismStatCode;
    }

    public void setPoPrismStatCode(String poPrismStatCode) {
        this.poPrismStatCode = poPrismStatCode;
    }

    public String getShipDateTypeCode() {
        return shipDateTypeCode;
    }

    public void setShipDateTypeCode(String shipDateTypeCode) {
        this.shipDateTypeCode = shipDateTypeCode;
    }

    public String getEarlyShipBeginDate() {
        return earlyShipBeginDate;
    }

    public void setEarlyShipBeginDate(String earlyShipBeginDate) {
        this.earlyShipBeginDate = earlyShipBeginDate;
    }

    public String getLateShipEndDate() {
        return lateShipEndDate;
    }

    public void setLateShipEndDate(String lateShipEndDate) {
        this.lateShipEndDate = lateShipEndDate;
    }

    public String getLateShipEtaDate() {
        return lateShipEtaDate;
    }

    public void setLateShipEtaDate(String lateShipEtaDate) {
        this.lateShipEtaDate = lateShipEtaDate;
    }

    public String getPoScndStatCode() {
        return poScndStatCode;
    }

    public void setPoScndStatCode(String poScndStatCode) {
        this.poScndStatCode = poScndStatCode;
    }

    public String getAlocDueDate() {
        return alocDueDate;
    }

    public void setAlocDueDate(String alocDueDate) {
        this.alocDueDate = alocDueDate;
    }

    public String getPymtTypeCode() {
        return pymtTypeCode;
    }

    public void setPymtTypeCode(String pymtTypeCode) {
        this.pymtTypeCode = pymtTypeCode;
    }

    public String getOrdPrpsCode() {
        return ordPrpsCode;
    }

    public void setOrdPrpsCode(String ordPrpsCode) {
        this.ordPrpsCode = ordPrpsCode;
    }

    public String getShipTermsCode() {
        return shipTermsCode;
    }

    public void setShipTermsCode(String shipTermsCode) {
        this.shipTermsCode = shipTermsCode;
    }

    public String getDistbModeCode() {
        return distbModeCode;
    }

    public void setDistbModeCode(String distbModeCode) {
        this.distbModeCode = distbModeCode;
    }

    public Integer getSpclTermMoId() {
        return spclTermMoId;
    }

    public void setSpclTermMoId(Integer spclTermMoId) {
        this.spclTermMoId = spclTermMoId;
    }

    public Integer getScplTermYrId() {
        return scplTermYrId;
    }

    public void setScplTermYrId(Integer scplTermYrId) {
        this.scplTermYrId = scplTermYrId;
    }

    public Integer getOtbMonId() {
        return otbMonId;
    }

    public void setOtbMonId(Integer otbMonId) {
        this.otbMonId = otbMonId;
    }

    public Integer getOtbMoWkId() {
        return otbMoWkId;
    }

    public void setOtbMoWkId(Integer otbMoWkId) {
        this.otbMoWkId = otbMoWkId;
    }

    public Integer getOtbYrId() {
        return OtbYrId;
    }

    public void setOtbYrId(Integer otbYrId) {
        OtbYrId = otbYrId;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getApproveUserId() {
        return approveUserId;
    }

    public void setApproveUserId(String approveUserId) {
        this.approveUserId = approveUserId;
    }

    public String getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(String cancelDate) {
        this.cancelDate = cancelDate;
    }

    public String getCancelUserId() {
        return cancelUserId;
    }

    public void setCancelUserId(String cancelUserId) {
        this.cancelUserId = cancelUserId;
    }

    public String getReinsDate() {
        return reinsDate;
    }

    public void setReinsDate(String reinsDate) {
        this.reinsDate = reinsDate;
    }

    public String getReinsUserId() {
        return reinsUserId;
    }

    public void setReinsUserId(String reinsUserId) {
        this.reinsUserId = reinsUserId;
    }

    public String getImpOrdFlag() {
        return impOrdFlag;
    }

    public void setImpOrdFlag(String impOrdFlag) {
        this.impOrdFlag = impOrdFlag;
    }

    public String getBoAuthOvrdFlag() {
        return boAuthOvrdFlag;
    }

    public void setBoAuthOvrdFlag(String boAuthOvrdFlag) {
        this.boAuthOvrdFlag = boAuthOvrdFlag;
    }

    public String getFrtAllowOvrdFlag() {
        return frtAllowOvrdFlag;
    }

    public void setFrtAllowOvrdFlag(String frtAllowOvrdFlag) {
        this.frtAllowOvrdFlag = frtAllowOvrdFlag;
    }

    public String getFobPntOvrdFlag() {
        return fobPntOvrdFlag;
    }

    public void setFobPntOvrdFlag(String fobPntOvrdFlag) {
        this.fobPntOvrdFlag = fobPntOvrdFlag;
    }

    public String getImpStrgFlag() {
        return impStrgFlag;
    }

    public void setImpStrgFlag(String impStrgFlag) {
        this.impStrgFlag = impStrgFlag;
    }

    public Integer getOrdMinStoreQty() {
        return ordMinStoreQty;
    }

    public void setOrdMinStoreQty(Integer ordMinStoreQty) {
        this.ordMinStoreQty = ordMinStoreQty;
    }

    public Integer getOrdMinDcQty() {
        return ordMinDcQty;
    }

    public void setOrdMinDcQty(Integer ordMinDcQty) {
        this.ordMinDcQty = ordMinDcQty;
    }

    public String getOrdMinMeasCode() {
        return ordMinMeasCode;
    }

    public void setOrdMinMeasCode(String ordMinMeasCode) {
        this.ordMinMeasCode = ordMinMeasCode;
    }

    public String getVendMinStatCode() {
        return vendMinStatCode;
    }

    public void setVendMinStatCode(String vendMinStatCode) {
        this.vendMinStatCode = vendMinStatCode;
    }

    public String getIpiFlag() {
        return ipiFlag;
    }

    public void setIpiFlag(String ipiFlag) {
        this.ipiFlag = ipiFlag;
    }

    public String getOrdConsFlag() {
        return ordConsFlag;
    }

    public void setOrdConsFlag(String ordConsFlag) {
        this.ordConsFlag = ordConsFlag;
    }

    public String getVendPromoId() {
        return vendPromoId;
    }

    public void setVendPromoId(String vendPromoId) {
        this.vendPromoId = vendPromoId;
    }

    public String getAlocAutoAppFlag() {
        return alocAutoAppFlag;
    }

    public void setAlocAutoAppFlag(String alocAutoAppFlag) {
        this.alocAutoAppFlag = alocAutoAppFlag;
    }

    public String getAlocReqFlag() {
        return alocReqFlag;
    }

    public void setAlocReqFlag(String alocReqFlag) {
        this.alocReqFlag = alocReqFlag;
    }

    public String getBulLockFlag() {
        return BulLockFlag;
    }

    public void setBulLockFlag(String bulLockFlag) {
        BulLockFlag = bulLockFlag;
    }

    public String getAutoReplPurgeFlag() {
        return autoReplPurgeFlag;
    }

    public void setAutoReplPurgeFlag(String autoReplPurgeFlag) {
        this.autoReplPurgeFlag = autoReplPurgeFlag;
    }

    public String getRecalcReqFlag() {
        return recalcReqFlag;
    }

    public void setRecalcReqFlag(String recalcReqFlag) {
        this.recalcReqFlag = recalcReqFlag;
    }

    public String getVendToGuesTFlag() {
        return vendToGuesTFlag;
    }

    public void setVendToGuesTFlag(String vendToGuesTFlag) {
        this.vendToGuesTFlag = vendToGuesTFlag;
    }

    public String getOwnBrandFlag() {
        return ownBrandFlag;
    }

    public void setOwnBrandFlag(String ownBrandFlag) {
        this.ownBrandFlag = ownBrandFlag;
    }

    public String getReqApproveTS() {
        return reqApproveTS;
    }

    public void setReqApproveTS(String reqApproveTS) {
        this.reqApproveTS = reqApproveTS;
    }

    public String getPoUpdateLockFlag() {
        return poUpdateLockFlag;
    }

    public void setPoUpdateLockFlag(String poUpdateLockFlag) {
        this.poUpdateLockFlag = poUpdateLockFlag;
    }

    public Integer getSrcTrakCode() {
        return srcTrakCode;
    }

    public void setSrcTrakCode(Integer srcTrakCode) {
        this.srcTrakCode = srcTrakCode;
    }

    public String getAutoCanExclFlag() {
        return autoCanExclFlag;
    }

    public void setAutoCanExclFlag(String autoCanExclFlag) {
        this.autoCanExclFlag = autoCanExclFlag;
    }

    public Integer getPoId() {
        return poId;
    }

    public void setPoId(Integer poId) {
        this.poId = poId;
    }

    public String getPoNumSourceCode() {
        return poNumSourceCode;
    }

    public void setPoNumSourceCode(String poNumSourceCode) {
        this.poNumSourceCode = poNumSourceCode;
    }

    public String getLgclDelFlag() {
        return lgclDelFlag;
    }

    public void setLgclDelFlag(String lgclDelFlag) {
        this.lgclDelFlag = lgclDelFlag;
    }

    public String getPoActFlag() {
        return poActFlag;
    }

    public void setPoActFlag(String poActFlag) {
        this.poActFlag = poActFlag;
    }

    public Integer getVendId() {
        return vendId;
    }

    public void setVendId(Integer vendId) {
        this.vendId = vendId;
    }

    public Integer getVendShipPntId() {
        return vendShipPntId;
    }

    public void setVendShipPntId(Integer vendShipPntId) {
        this.vendShipPntId = vendShipPntId;
    }

    public String getFobPoint() {
        return fobPoint;
    }

    public void setFobPoint(String fobPoint) {
        this.fobPoint = fobPoint;
    }

    public String getFrtAllow() {
        return frtAllow;
    }

    public void setFrtAllow(String frtAllow) {
        this.frtAllow = frtAllow;
    }

    public String getRtgCode() {
        return rtgCode;
    }

    public void setRtgCode(String rtgCode) {
        this.rtgCode = rtgCode;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public String getConfOrdFlag() {
        return confOrdFlag;
    }

    public void setConfOrdFlag(String confOrdFlag) {
        this.confOrdFlag = confOrdFlag;
    }

    public String getPoAutoGenCode() {
        return poAutoGenCode;
    }

    public void setPoAutoGenCode(String poAutoGenCode) {
        this.poAutoGenCode = poAutoGenCode;
    }

    public String getPoNumTypeCode() {
        return poNumTypeCode;
    }

    public void setPoNumTypeCode(String poNumTypeCode) {
        this.poNumTypeCode = poNumTypeCode;
    }

    public String getOoPoCanFlag() {
        return ooPoCanFlag;
    }

    public void setOoPoCanFlag(String ooPoCanFlag) {
        this.ooPoCanFlag = ooPoCanFlag;
    }

    public String getImpCanFlag() {
        return impCanFlag;
    }

    public void setImpCanFlag(String impCanFlag) {
        this.impCanFlag = impCanFlag;
    }

    public String getPoCreateCode() {
        return poCreateCode;
    }

    public void setPoCreateCode(String poCreateCode) {
        this.poCreateCode = poCreateCode;
    }

    public String getApproveDate() {
        return approveDate;
    }

    public void setApproveDate(String approveDate) {
        this.approveDate = approveDate;
    }

    public Integer getAppriveStatCode() {
        return appriveStatCode;
    }

    public void setAppriveStatCode(Integer appriveStatCode) {
        this.appriveStatCode = appriveStatCode;
    }
}
