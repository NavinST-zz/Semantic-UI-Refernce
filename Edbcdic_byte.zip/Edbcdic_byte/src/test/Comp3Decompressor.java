package test;

import net.sf.JRecord.Common.Constants;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.JRecord.External.CopybookLoader;
import net.sf.JRecord.IO.AbstractLineReader;
import net.sf.JRecord.IO.CobolIoProvider;
import net.sf.JRecord.Numeric.Convert;
import net.sf.cb2xml.def.Cb2xmlConstants;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Created by NavinST on 18-03-2017.
 */
public class Comp3Decompressor {

    private static final Logger logger = Logger.getLogger(Comp3Decompressor.class.getName());

    private String compressedFilePath;
    private String copybookFilePath;
    private List<String> outputFileHeaders;
    private String outputFilePath;

    public String getCompressedFilePath() {
        return compressedFilePath;
    }

    public void setCompressedFilePath(String compressedFilePath) {
        this.compressedFilePath = compressedFilePath;
    }

    public String getCopybookFilePath() {
        return copybookFilePath;
    }

    public void setCopybookFilePath(String copybookFilePath) {
        this.copybookFilePath = copybookFilePath;
    }

    public List<String> getOutputFileHeaders() {
        return outputFileHeaders;
    }

    public void setOutputFileHeaders(List<String> outputFileHeaders) {
        this.outputFileHeaders = outputFileHeaders;
    }

    public String getOutputFilePath() {
        return outputFilePath;
    }

    public void setOutputFilePath(String outputFilePath) {
        this.outputFilePath = outputFilePath;
    }

    public Comp3Decompressor(String compressedFilePath, String copybookFilePath) {
        this.setCompressedFilePath(compressedFilePath);
        this.setCopybookFilePath(copybookFilePath);
    }

    public List<InputFileLine> decompressFile() {
        List<InputFileLine> lines = new ArrayList<>();
        try {
            CobolIoProvider ioProvider = CobolIoProvider.getInstance();
            AbstractLine line;
            AbstractLineReader reader = ioProvider.getLineReader(Constants.FULL_LINE, Convert.FMT_MAINFRAME,
                    CopybookLoader.SPLIT_NONE, this.copybookFilePath, this.compressedFilePath);
            while((line = reader.read()) != null)
            {
                InputFileLine ln = new InputFileLine();
                ln.setPoId(line.getFieldValue("PO-I").asInt());
                ln.setPoNumSourceCode(line.getFieldValue("PO-NUM-SOURCE-C").asString());
                ln.setLgclDelFlag(line.getFieldValue("LGCL-DEL-F").asString());
                ln.setPoActFlag(line.getFieldValue("PO-ACT-F").asString());
                ln.setVendId(line.getFieldValue("VEND-I").asInt());
                ln.setVendShipPntId(line.getFieldValue("VEND-SHIP-PNT-I").asInt());
                ln.setFobPoint(line.getFieldValue("FOB-PNT-T").asString());
                ln.setFrtAllow(line.getFieldValue("FRT-ALOW-T").asString());
                ln.setRtgCode(line.getFieldValue("RTG-C").asString());
                ln.setCreateDate(line.getFieldValue("CREATE-D").asString());
                ln.setConfOrdFlag(line.getFieldValue("CONF-ORD-F").asString());
                ln.setPoAutoGenCode(line.getFieldValue("PO-AUTO-GEN-C").asString());
                ln.setPoNumTypeCode(line.getFieldValue("PO-NUM-TYPE-C").asString());
                ln.setOoPoCanFlag(line.getFieldValue("OOF-PO-CAN-F").asString());
                ln.setImpCanFlag(line.getFieldValue("IMP-CAN-C").asString());
                ln.setPoCreateCode(line.getFieldValue("PO-CREATE-C").asString());
                ln.setApproveDate(line.getFieldValue("APPRO-D").asString());
                ln.setAppriveStatCode(line.getFieldValue("APPRO-STAT-C").asInt());
                ln.setBoAuthFlg(line.getFieldValue("BO-AUTH-F").asString());
                ln.setTermsOverrideCode(line.getFieldValue("TERMS-OVRIDE-C").asString());
                ln.setDiscPd(line.getFieldValue("DISC-PD").asFloat());
                ln.setDatingTermsCode(line.getFieldValue("DATING-TERMS-C").asString());
                ln.setDatingTermdQty(line.getFieldValue("DATING-TERMS-Q").asInt());
                ln.setAddlTermsTypeCode(line.getFieldValue("ADDL-TERMS-TYPE-C").asString());
                ln.setAddlDiscPd(line.getFieldValue("ADDL-DISC-PD").asFloat());
                ln.setAddlDatingTermsQty(line.getFieldValue("ADDL-DATING-TERM-Q").asInt());
                ln.setChangeDate(line.getFieldValue("CHG-D").asString());
                /*ln.setChangeUser(line.getFieldValue("CHG-USER-I").asString());
                ln.setPoPrismStatCode(line.getFieldValue("PO-PRIM-STAT-C").asString());
                ln.setShipDateTypeCode(line.getFieldValue("SHIP-DATE-TYPE-C").asString());
                ln.setEarlyShipBeginDate(line.getFieldValue("EARLY-SHIP-BEGIN-D").asString());
                ln.setLateShipEndDate(line.getFieldValue("LATE-SHIP-END-D").asString());
                ln.setLateShipEtaDate(line.getFieldValue("LATE-ETA-D").asString());
                ln.setPoScndStatCode(line.getFieldValue("PO-SCND-STAT-C").asString());
                ln.setAlocDueDate(line.getFieldValue("ALOC-DUE-D").asString());
                ln.setPymtTypeCode(line.getFieldValue("PYMT-TYPE-C").asString());
                ln.setOrdPrpsCode(line.getFieldValue("ORD-PRPS-C").asString());
                ln.setShipTermsCode(line.getFieldValue("SHIP-TRM-C").asString());
                ln.setDistbModeCode(line.getFieldValue("DISTB-MODE-C").asString());
                ln.setSpclTermMoId(line.getFieldValue("SPCL-TRM-MO-I").asInt());
                ln.setScplTermYrId(line.getFieldValue("SPCL-TRM-YR-I").asInt());
                ln.setOtbMonId(line.getFieldValue("OTB-MO-I").asInt());
                ln.setOtbMoWkId(line.getFieldValue("OTB-MO-WK-I").asInt());
                ln.setOtbYrId(line.getFieldValue("OTB-YR-I").asInt());
                ln.setCreateUserId(line.getFieldValue("CREATE-USER-I").asString());
                ln.setApproveUserId(line.getFieldValue("APPRO-USER-I").asString());
                ln.setCancelDate(line.getFieldValue("CAN-D").asString());
                ln.setCancelUserId(line.getFieldValue("CAN-BY-USER-I").asString());
                ln.setReinsDate(line.getFieldValue("REINST-D").asString());
                ln.setReinsUserId(line.getFieldValue("REINST-BY-USER-I").asString());
                ln.setImpOrdFlag(line.getFieldValue("IMP-ORD-F").asString());
                ln.setBoAuthOvrdFlag(line.getFieldValue("BO-AUTH-OVRIDE-F").asString());
                ln.setFrtAllowOvrdFlag(line.getFieldValue("FRT-ALOW-OVRIDE-F").asString());
                ln.setFobPntOvrdFlag(line.getFieldValue("FOB-PNT-OVRIDE-F").asString());
                ln.setImpStrgFlag(line.getFieldValue("IMP-STRG-F").asString());
                ln.setOrdMinStoreQty(line.getFieldValue("ORD-MIN-STORE-Q").asInt());
                ln.setOrdMinDcQty(line.getFieldValue("ORD-MIN-DC-Q").asInt());
                ln.setOrdMinMeasCode(line.getFieldValue("ORD-MIN-MEAS-C").asString());
                ln.setVendMinStatCode(line.getFieldValue("VEND-MIN-STAT-C").asString());
                ln.setIpiFlag(line.getFieldValue("IPI-F").asString());
                ln.setOrdConsFlag(line.getFieldValue("ORD-CONS-F").asString());
                ln.setVendPromoId(line.getFieldValue("VEND-PROMO-I").asString());
                ln.setAlocAutoAppFlag(line.getFieldValue("ALOC-AUTO-APPRO-F").asString());
                ln.setAlocReqFlag(line.getFieldValue("ALOC-REQ-F").asString());
                ln.setBulLockFlag(line.getFieldValue("BLK-LOC-F").asString());
                ln.setAutoReplPurgeFlag(line.getFieldValue("AUTO-REPLN-PURGE-C").asString());
                ln.setRecalcReqFlag(line.getFieldValue("RECALC-REQR-F").asString());
                ln.setVendToGuesTFlag(line.getFieldValue("VEND-TO-GUEST-F").asString());
                ln.setOwnBrandFlag(line.getFieldValue("OWN-BRAND-F").asString());
                ln.setReqApproveTS(line.getFieldValue("REQ-APPRO-TS").asString());
                ln.setPoUpdateLockFlag(line.getFieldValue("PO-UPDT-LK-F").asString());
                ln.setSrcTrakCode(line.getFieldValue("SRC-TRAK-C").asInt());
                ln.setAutoCanExclFlag(line.getFieldValue("AUTO-CAN-EXCL-F").asString());*/
                lines.add(ln);
            }
            reader.close();
        }
        catch(Exception e)
        {
            logger.info(e.getMessage());
            e.printStackTrace();
        }
        return lines;
    }
}
